package com.udacity.nanodegree.carservicebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarServiceBackEndApplicationTests {

    @Test
    void contextLoads() {
    }

}
